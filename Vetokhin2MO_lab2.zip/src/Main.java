public class Main {

    public static void main(String[] args) {

        MyStack<Integer> stack = new MyStack<>();

        // Добавление элементов
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Вывод стека
        stack.printStack();

        System.out.println();

        // Верхний элемент
        System.out.println("Top element: " + stack.peek());

        // Удаление элемента
        System.out.println("Removed: " + stack.pop());

        System.out.println();

        // Состояние стека после удаления
        stack.printStack();

        System.out.println();

        // Размер стека
        System.out.println("Stack size: " + stack.size());

        // Проверка на пустоту
        System.out.println("Is empty: " + stack.isEmpty());
    }
}