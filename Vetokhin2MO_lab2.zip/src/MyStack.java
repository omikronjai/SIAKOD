public class MyStack<T> implements Stack<T> {

    /**
     * Узел связного списка
     */
    private static class Node<T> {

        T value;
        Node<T> next;

        Node(T value) {
            this.value = value;
        }
    }

    /**
     * Вершина стека
     */
    private Node<T> top;

    /**
     * Количество элементов
     */
    private int size;

    /**
     * Добавление элемента в стек
     * Сложность: O(1)
     */
    @Override
    public void push(T value) {

        Node<T> newNode = new Node<>(value);

        newNode.next = top;
        top = newNode;

        size++;
    }

    /**
     * Удаление верхнего элемента
     * Сложность: O(1)
     */
    @Override
    public T pop() {

        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }

        T value = top.value;

        top = top.next;

        size--;

        return value;
    }

    /**
     * Просмотр верхнего элемента
     * без удаления
     */
    @Override
    public T peek() {

        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }

        return top.value;
    }

    /**
     * Возвращает количество элементов
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * Проверка стека на пустоту
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Вывод содержимого стека
     */
    public void printStack() {

        Node<T> current = top;

        System.out.println("Stack:");

        while (current != null) {
            System.out.println(current.value);
            current = current.next;
        }
    }
}