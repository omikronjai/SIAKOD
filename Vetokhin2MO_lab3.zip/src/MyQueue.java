public class MyQueue<T> implements Queue<T> {

    /**
     * Узел связного списка
     */
    private static class Node<T> {

        T value;
        Node<T> next;

        Node(T value) {
            this.value = value;
        }
    }

    /**
     * Начало очереди
     */
    private Node<T> head;

    /**
     * Конец очереди
     */
    private Node<T> tail;

    /**
     * Количество элементов
     */
    private int size;

    /**
     * Добавление элемента в конец очереди
     * Сложность: O(1)
     */
    @Override
    public void enqueue(T value) {

        Node<T> newNode = new Node<>(value);

        if (isEmpty()) {

            head = newNode;
            tail = newNode;

        } else {

            tail.next = newNode;
            tail = newNode;
        }

        size++;
    }

    /**
     * Удаление элемента из начала очереди
     * Сложность: O(1)
     */
    @Override
    public T dequeue() {

        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }

        T value = head.value;

        head = head.next;

        size--;

        // Если очередь стала пустой
        if (head == null) {
            tail = null;
        }

        return value;
    }

    /**
     * Просмотр первого элемента
     * без удаления
     */
    @Override
    public T peek() {

        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }

        return head.value;
    }

    /**
     * Возвращает количество элементов
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * Проверка очереди на пустоту
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Вывод элементов очереди
     */
    public void printQueue() {

        Node<T> current = head;

        System.out.println("Queue:");

        while (current != null) {

            System.out.println(current.value);

            current = current.next;
        }
    }
}