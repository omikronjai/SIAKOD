public class Main {

    public static void main(String[] args) {

        MyQueue<String> queue = new MyQueue<>();

        // Добавление элементов
        queue.enqueue("Alex");
        queue.enqueue("Maria");
        queue.enqueue("John");

        // Вывод очереди
        queue.printQueue();

        System.out.println();

        // Первый элемент
        System.out.println("First element: " + queue.peek());

        // Удаление элемента
        System.out.println("Removed: " + queue.dequeue());

        System.out.println();

        // Очередь после удаления
        queue.printQueue();

        System.out.println();

        // Размер очереди
        System.out.println("Queue size: " + queue.size());

        // Проверка на пустоту
        System.out.println("Is empty: " + queue.isEmpty());
    }
}